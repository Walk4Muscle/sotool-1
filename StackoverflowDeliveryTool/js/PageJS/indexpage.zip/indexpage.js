﻿var _userAlias = $("#userspan").html().substring($("#userspan").html().indexOf("\\") + 1);

$(document).ready(function () {
   
    ClearHTMLTempData();
    LoadInitialData();
    BindControlEvent();
});

function ClearHTMLTempData() {
    $("#questionTBody").empty();
    $("#selectSs").empty();
    reLoadTable();
    docReady();
}

function LoadInitialData() {
    // Load Data for Dashborad
    LoadDashBoardData();
    // Load data for dropdownlist
    LoadScenarioDropdown();
    LoadEngineerDropdown();
}
function LoadEngineerDropdown()
{
    GetServiceFunctions("GET", "ThreadsGeneration.svc/GetSElist").then(function (args) { LoadSEngineerDropdownCallBack(args) }, function (JQresponse, err) { alert(CallSerivceError(JQresponse, err)); });
}
function LoadScenarioDropdown() {
    GetServiceFunctions("GET", "ThreadsGeneration.svc/GetScenarios").then(function (args) { LoadScenarioDropdownCallBack(args) }, function (JQresponse, err) { alert(CallSerivceError(JQresponse, err)); });
}
function LoadSEngineerDropdownCallBack(args) {
    if (args.length > 0) {
        $("#selectSE").empty();
        var optionTop = $("<option value=\"\">");
        $("#selectSE").append(optionTop);
        var optionSEAll = $("<optgroup label=\"Engineers' Alias\">");
        $.each(args, function (i, item) {
            optionSEAll.append("<option value=\"" + item.Alias + "\">" + item.Alias + "</option>");
        });
        $("#selectSE").append(optionSEAll);
        $("#selectSE").trigger('liszt:updated');
    }
}
function LoadScenarioDropdownCallBack(args) {
    if (args.length > 0) {
      
        $("#selectSs").empty();
        var optionTop = $("<option value=\"\">");
        $("#selectSs").append(optionTop);
        var optionAzureGroup = $("<optgroup label=\"Open Source On Azure\">");
        var optionAzureStorageGroup = $("<optgroup label=\"Azure Storage & Data\">");
        var optionAzureNetonAzure = $("<optgroup label=\".Net on Azure\">");
        var optionAzureService = $("<optgroup label=\"Azure Services\">");
        var optionAzureTools = $("<optgroup label=\"Azure Tools\">");
       
        var optionAzureAD = $("<optgroup label=\"Azure AD\">");
        var optionCsAzure=$("<optgroup label=\"C# on Azure\">");
        var optionAzureMS=$("<optgroup label=\"Azure Resource Manager\">");
        var optionAzureMoblieSer=$("<optgroup label=\"Azure Mobile Service\">");
        var optionAzureXamarin=$("<optgroup label=\"Azure Xamarin \">");
        var optionAzureRuby = $("<optgroup label=\"Azure Ruby\">");

        var optionAzureSQLGroup = $("<optgroup label=\"Azure SQL & MySQL\">"); //add by jambor

        var optionMobilityGroup = $("<optgroup label=\"Mobility\">");

        var optionIOTGroup = $("<optgroup label=\"Windows IOT\">");
        var optionVSALMGroup = $("<optgroup label=\"VSALM\">");
        var optionVSOGroup = $("<optgroup label=\"VSO\">");
        var optionWinTenGroup = $("<optgroup label=\"Win10\">");
        var optionUWPTenGroup = $("<optgroup label=\"UWP\">");
        var optionUWPW10 = $("<optgroup label=\"UWP-Win10\">");
        var optionQ2PlanGroup = $("<optgroup label=\"Office 365\">");
        var optionCordovaGroup = $("<optgroup label=\"VS Tools for Cordova\">");
        var optionHockeyAppGroup = $("<optgroup label=\"\Hockey\">");
        var optionDevCenterdGroup = $("<optgroup label=\"\Dev Center\">");
        var optionAzureHybridGroup = $("<optgroup label=\"\Azure Hybrid Linux\">");
        
        $.each(args, function (i, item) {
            if (item.Category == "Azure") {
                optionAzureGroup.append("<option scenario=\"" + item.id + "\" value=\"" + item.Tags + "\">" + item.ScenarioName + "</option>");
            }
            if (item.Category == "AzureStorage&Data")
            {
                optionAzureStorageGroup.append("<option scenario=\"" + item.id + "\" value=\"" + item.Tags + "\">" + item.ScenarioName + "</option>");
            }

            if (item.Category == "NETonAzure") {
                optionAzureNetonAzure.append("<option scenario=\"" + item.id + "\" value=\"" + item.Tags + "\">" + item.ScenarioName + "</option>");
            }
            if (item.Category == "AzureServices") {
                optionAzureService.append("<option scenario=\"" + item.id + "\" value=\"" + item.Tags + "\">" + item.ScenarioName + "</option>");

            }

            if (item.Category == "AzureTools") {
                optionAzureTools.append("<option scenario=\"" + item.id + "\" value=\"" + item.Tags + "\">" + item.ScenarioName + "</option>");
            }           
            if (item.Category == "AzureAD") {
                optionAzureAD.append("<option scenario=\"" + item.id + "\" value=\"" + item.Tags + "\">" + item.ScenarioName + "</option>");
            }
            if (item.Category == "AzureResourceManager") {
                optionAzureMS.append("<option scenario=\"" + item.id + "\" value=\"" + item.Tags + "\">" + item.ScenarioName + "</option>");
            }

            if (item.Category == "C#OnAzure") {
                optionCsAzure.append("<option scenario=\"" + item.id + "\" value=\"" + item.Tags + "\">" + item.ScenarioName + "</option>");
            }
            if (item.Category == "AzureMobileService") {
                optionAzureMoblieSer.append("<option scenario=\"" + item.id + "\" value=\"" + item.Tags + "\">" + item.ScenarioName + "</option>");
            }
            if (item.Category == "XamarinAzure") {
                optionAzureXamarin.append("<option scenario=\"" + item.id + "\" value=\"" + item.Tags + "\">" + item.ScenarioName + "</option>");
            }
            if (item.Category == "Azure&Ruby") {
                optionAzureRuby.append("<option scenario=\"" + item.id + "\" value=\"" + item.Tags + "\">" + item.ScenarioName + "</option>");
            }

            if (item.Category == "SQLAzure" || item.Category == "AzureMySQL") //add by jambor
            {
                optionAzureSQLGroup.append("<option scenario=\"" + item.id + "\" value=\"" + item.Tags + "\">" + item.ScenarioName + "</option>");
            }
           

            if (item.Category == "Mobility") {
                optionMobilityGroup.append("<option scenario=\"" + item.id + "\" value=\"" + item.Tags + "\">" + item.ScenarioName + "</option>");
            }

            if (item.Category == "WindowsIOT")
            {
                optionIOTGroup.append("<option scenario=\"" + item.id + "\" value=\"" + item.Tags + "\">" + item.ScenarioName + "</option>");

            }
            if (item.Category == "VSALM") {
                optionVSALMGroup.append("<option scenario=\"" + item.id + "\" value=\"" + item.Tags + "\">" + item.ScenarioName + "</option>");
            }
            if (item.Category == "VSO") {
                optionVSOGroup.append("<option scenario=\"" + item.id + "\" value=\"" + item.Tags + "\">" + item.ScenarioName + "</option>");
            }
            if (item.Category == "WIN10") {
                optionWinTenGroup.append("<option scenario=\"" + item.id + "\" value=\"" + item.Tags + "\">" + item.ScenarioName + "</option>");
            }
            if (item.Category == "UWP") {
                optionUWPTenGroup.append("<option scenario=\"" + item.id + "\" value=\"" + item.Tags + "\">" + item.ScenarioName + "</option>");
            }
            if (item.Category == "UWPWin10") {
                optionUWPW10.append("<option scenario=\"" + item.id + "\" value=\"" + item.Tags + "\">" + item.ScenarioName + "</option>");
            }

            if (item.Category == "O365") {
                optionQ2PlanGroup.append("<option scenario=\"" + item.id + "\" value=\"" + item.Tags + "\">" + item.ScenarioName + "</option>");
            }
            if (item.Category == "VSForCordova") {
                optionCordovaGroup.append("<option scenario=\"" + item.id + "\" value=\"" + item.Tags + "\">" + item.ScenarioName + "</option>");
            }
            if (item.Category == "Hockey") {
                optionHockeyAppGroup.append("<option scenario=\"" + item.id + "\" value=\"" + item.Tags + "\">" + item.ScenarioName + "</option>");
            }
            if (item.Category == "DevCenter")
            {
                optionDevCenterdGroup.append("<option scenario=\"" + item.id + "\" value=\"" + item.Tags + "\">" + item.ScenarioName + "</option>");

            }
            if (item.Category == "AzureHybridLinux") {
                optionAzureHybridGroup.append("<option scenario=\"" + item.id + "\" value=\"" + item.Tags + "\">" + item.ScenarioName + "</option>");
            }

        });
        //Category=N'AzureAD' or Category=N'NETonAzure' "
        //                   +"or Category=N'AzureResourceManager' or Category=N'AzureMobileService' "
        //                   +"or Category=N'C#OnAzure' or Category=N'XamarinAzure' or Category=N'Azure&Ruby'
        var optionAzureAll = $("<option scenario=\"opensourceall\" value=\" Open Source on Azure All\">Open Source on Azure All</option>");

        var optionAzureStorageAll = $("<option scenario=\"AzureStorageAll\" value=\"Azure Storage All\">Azure Storage All</option>");
        var optionAzureNetonAzureAll = $("<option scenario=\"NetonAzureAll\" value=\".Net on Azure All\">.Net on Azure All</option>");
        var optionAzureServiceAll = $("<option scenario=\"AzureServiceAll\" value=\"Azure Service All\">Azure Service All</option>");
        var optionAzureToolsAll = $("<option scenario=\"AzureToolsAll\" value=\"Azure Tools All\">Azure Tools All</option>");
        var optionAzureADAll = $("<option scenario=\"AzureADAll\" value=\"Azure AD All\">Azure AD All</option>");
        var optionAzureCsonAzureAll = $("<option scenario=\"csonazure\" value=\"C# on Azure All\">C# on Azure All</option>");
        var optionAzureAzureResourceManagerAll = $("<option scenario=\"azureresourcemanager\" value=\"Azure Resource Manager All\">Azure Resource Manager All</option>");
        var optionAzureAzureMoblieSerAll = $("<option scenario=\"azuremobileservice\" value=\"Azure Mobile ServiceAll\"Azure Mobile Service All</option>");
        var optionAzureAzureXamarinAll = $("<option scenario=\"azurexamarin\" value=\"Azure Xamarin All\">Azure Xamarin All</option>");
        var optionAzureAzureRubyAll = $("<option scenario=\"azureruby\" value=\"Azure Ruby All\">Azure Ruby All</option>");


    
        var optionMobilityAll = $("<option scenario=\"mobilityall\" value=\"Mobility All\">Mobility All</option>");
        var optionIOTALL = $("<option scenario=\"iotall\" value=\"Windows IOT All\">Windows IOT All</option>");
        var optionVSALMAll = $("<option scenario=\"vsalmall\" value=\"VSALM All\">VSALM All</option>");
        var optionVSOAll = $("<option scenario=\"vsoall\" value=\"VSO All\">VSO All</option>");
        var optionWinTenAll = $("<option scenario=\"win10all\" value=\"Win10 All\">Win10 All</option>");
        var optionUWPAll = $("<option scenario=\"uwpall\" value=\"UWP All\">UWP All</option>");
        var optionQ2PannedAll = $("<option scenario=\"o365all\" value=\"O365 All\">Office 365 All</option>");
        var optionCordovaall = $("<option scenario=\"cordovaall\" value=\"cordovaall\">Cordova All</option>");
        var optionHockeydAll = $("<option scenario=\"hockeyall\" value=\"Hockey All\">Hockey All</option>");
        var optionUWPW10All = $("<option scenario=\"uwpwin10\" value=\"uwp-win10 All\">uwp-win10 All</option>");
        var optionAzureHybridLinuxAll = $("<option scenario=\"azurehybridlinuxall\" value=\"Azure Hybrid Linux All\">Azure Hybrid Linux All</option>");
        var optionAzureSQLAll = $("<option scenario=\"azuresqlall\" value=\"Azure SQL & MySQL All\">Azure SQL & MySQL All</option>"); // add by Jambor
        
        optionAzureGroup.append(optionAzureAll);
        optionAzureStorageGroup.append(optionAzureStorageAll);
        optionAzureNetonAzure.append(optionAzureNetonAzureAll);
        optionAzureService.append( optionAzureServiceAll);
        optionAzureTools.append(optionAzureToolsAll);

        optionAzureAD.append(optionAzureADAll);
        optionAzureSQLGroup.append(optionAzureSQLAll);

        optionCsAzure.append(optionAzureCsonAzureAll);
        optionAzureMS.append(optionAzureAzureResourceManagerAll);
        optionAzureMoblieSer.append(optionAzureAzureMoblieSerAll);
        optionAzureXamarin.append(optionAzureAzureXamarinAll);
        optionAzureRuby.append(optionAzureAzureRubyAll);


        optionMobilityGroup.append(optionMobilityAll);
        optionIOTGroup.append(optionIOTALL);
        optionVSALMGroup.append(optionVSALMAll);
        optionVSOGroup.append(optionVSOAll);
        optionWinTenGroup.append(optionWinTenAll);
        optionUWPTenGroup.append(optionUWPAll);
        optionUWPW10.append(optionUWPW10All);;
        optionQ2PlanGroup.append(optionQ2PannedAll);
        optionCordovaGroup.append(optionCordovaall);
        optionHockeyAppGroup.append(optionHockeydAll);
        optionDevCenterdGroup.append($("<option scenario=\"devcenterall\" value=\"Dev Center All\">Dev Center All</option>"));
        optionAzureHybridGroup.append(optionAzureHybridLinuxAll);
        var optionazureAllGroup = $("<optgroup label=\"Azure All Tags\"><option scenario=\"azurealltags\">Azure All Tags</option></optgroup>");
        $("#selectSs").append(optionazureAllGroup);
        $("#selectSs").append(optionAzureGroup);       
        $("#selectSs").append(optionAzureStorageGroup);
        $("#selectSs").append(optionAzureNetonAzure);
        $("#selectSs").append(optionAzureService);
        $("#selectSs").append(optionAzureTools);
        $("#selectSs").append(optionAzureAD);



        $("#selectSs").append(optionCsAzure);
        $("#selectSs").append(optionAzureMS);
        $("#selectSs").append(optionAzureMoblieSer);
        $("#selectSs").append(optionAzureXamarin);
        $("#selectSs").append(optionAzureRuby);

        $("#selectSs").append(optionMobilityGroup);
        $("#selectSs").append(optionIOTGroup);
        $("#selectSs").append(optionVSALMGroup);
        $("#selectSs").append(optionVSOGroup);
        $("#selectSs").append(optionWinTenGroup);
        $("#selectSs").append(optionUWPTenGroup);
        $("#selectSs").append(optionUWPW10);
        var optionUWPW10AllGroup = $("<optgroup label=\"UWP & Win10 All\"><option scenario=\"uwpandwin10\">UWP & Win10 All</option></optgroup>");
        $("#selectSs").append(optionUWPW10AllGroup);
        $("#selectSs").append(optionQ2PlanGroup);
        $("#selectSs").append(optionCordovaGroup);
        $("#selectSs").append(optionHockeyAppGroup);
        $("#selectSs").append(optionAzureSQLGroup); //add by jambor

        var optionVSBuildGroup = $("<optgroup label=\"\MS Build\">");
        optionVSBuildGroup.append($("<option scenario=\"msbuild\" value=\"MSBuild\">MSbuild</option>"));
        optionVSBuildGroup.append($("<option scenario=\"installation\" value=\"VS-Installation\">VS-Installation</option>"));
        optionVSBuildGroup.append($("<option scenario=\"debugging\" value=\"Debugging\">Debugging</option>"));
        optionVSBuildGroup.append($("<option scenario=\"version-git\" value=\"Git-Version-Control\">Git-Version-Control</option>"));
        optionVSBuildGroup.append($("<option scenario=\"extension\" value=\"VS-Extension\">VS-Extension</option>"));
        optionVSBuildGroup.append($("<option scenario=\"intellisense\" value=\"VS-Intelligence\">VS-Intelligence</option>"));
        optionVSBuildGroup.append($("<option scenario=\"nuget\" value=\"Nuget All\">Nuget All</option>"));
        optionVSBuildGroup.append($("<option scenario=\"msvsbuildall\" value=\"MS Build All\">MS Build All</option>"));
       

        var optionAllGroup = $("<optgroup label=\"All\"><option scenario=\"All\">All</option></optgroup>");
        $("#selectSs").append(optionVSBuildGroup);
        $("#selectSs").append(optionDevCenterdGroup);
        $("#selectSs").append(optionAzureHybridGroup);
        $("#selectSs").append(optionAllGroup);
        $("#selectSs").trigger('liszt:updated');
    }
}
function LoadDashBoardData() {
    GetServiceFunctions("GET", "ThreadsGeneration.svc/GetDashBoardProperties").then(function (args) { GetDashBoarddDataCallBack(args) }, function (JQresponse, err) { alert(CallSerivceError(JQresponse, err)); });
    GetDashBoarddData("NewThreadNo", "all", "New Thread", "3");
    GetDashBoarddData("RequiredFollow", "all", "Re-Open/Follow", "3");
    GetDashBoarddData("NoIR", "all", "All", "0");
    GetDashBoarddData("Replies", "all", "All", "1");
}
function GetDashBoarddData(type, scenarioId, status, delivery) {
    GetServiceFunctions("GET", "ThreadsGeneration.svc/GetDashBoardDate?scenarioId=" + scenarioId + "&status=" + status + "&delivery=" + delivery).then(function (args) { LoadDashBoradShowDataCallBack(args, type) }, function (JQresponse, err) { alert(CallSerivceError(JQresponse, err)); });
}
function LoadDashBoradShowDataCallBack(args, type) {
    $("#divTotal" + type).html(args.Total);
    $("#spanMy" + type).html(args.Personal);
    //$("#divTotal" + type).html(123);
}
function GetDashBoarddDataCallBack(args) {
    $("#NewThreadsSum").click(function () {
        QueryAuto(args.fromdate, args.todate, "all", "all", "0", "3");
        $("#NewThreadsSum").blur();
    });
    $("#FollowupSum").click(function () {
        QueryAuto(args.fromdate, args.todate, args.alias, "all", "3", "3");
        $("#FollowupSum").blur();
    });
    $("#NoIRSum").click(function () {
        QueryAuto(args.fromdate, args.todate, "all", "all", "6", "0");
        $("#NoIRSum").blur();
    });
    $("#RepliesSum").click(function () {
        QueryAuto(args.fromdate, args.todate, "all", "all", "6", "1");
        $("#RepliesSum").blur();
    });
}
function SearchOnSOF() {
    if (event.keyCode == 13) {
        window.open("http://stackoverflow.com/questions/tagged/" + $("#txbSearchForSOF").val());
    }
}
function QueryAuto(fromdate, todate, owner, scenarioId, status, delivery) {
    $("#txbFromDate").val(fromdate);
    $("#txbToDate").val(todate);
    $("#txbOwner").val(owner);
    $("#selectSs").find("option[scenario='" + scenarioId + "']").attr("selected", true).trigger('liszt:updated');
    $("#selectTS").val(status).trigger('liszt:updated');
    $("#selectDelivery").val(delivery).trigger('liszt:updated');
    $("#selectTS").change();
    $("#selectSs").change();
    $("#selectDelivery").change();
    $("#btnQuery").click();
    //$(".selector").val("pxx");
    //$(".selector").find("option[text='pxx']").attr("selected",true);
}

function showModel(question_id, obj) {
    $("#txbUT").val("");
    $("#textareaUTComments").val("");
    $('#myModalUT').modal('show');
    $("#btnSaveUILog").unbind("click");
    $("#btnSaveUILog").click(function () {
        var ut = $("#txbUT").val();
        var utcomments = $("#textareaUTComments").val()
        if (isErrorForLoggingUT(ut, utcomments, obj)) {
            GetServiceFunctions("GET", "ThreadsGeneration.svc/LogUTData?question_id=" + question_id + "&UT=" + ut + "&UTComments=" + utcomments).then(function (args) { LogUTDataCallBack(args, obj) }, function (JQresponse, err) { alert(CallSerivceError(JQresponse, err)); });
        }
    });
}
function LogUTDataCallBack(args, obj)
{
    $("#btnCloseUTModel").click();
    $(obj).html(args);
}
function isErrorForLoggingUT(ut, utcomments,obj)
{
    if (ut.trim() == "") {
        $("#txbUT").parent().parent().addClass("error");
        $(obj).attr("data-noty-options", "{\"text\":\"Please fill UT mins!\",\"layout\":\"top\",\"type\":\"error\",\"closeButton\":\"true\"}");
        var options = $.parseJSON($(obj).attr('data-noty-options'));
        noty(options);
        return false;
    }
    if (isNaN(ut.trim())) {
        $("#txbUT").parent().parent().addClass("error");
        $(obj).attr("data-noty-options", "{\"text\":\"Please fill UT as a number!\",\"layout\":\"top\",\"type\":\"error\",\"closeButton\":\"true\"}");
        var options = $.parseJSON($(obj).attr('data-noty-options'));
        noty(options);
        return false;
    }
    if (utcomments.trim() =="") {
        $("#textareaUTComments").parent().parent().addClass("error");
        $(obj).attr("data-noty-options", "{\"text\":\"Please fill UT's comments!\",\"layout\":\"top\",\"type\":\"error\",\"closeButton\":\"true\"}");
        var options = $.parseJSON($(obj).attr('data-noty-options'));
        noty(options);
        return false;
    }
    return true;
}
function showSRRadio()
{
    $('#SRModel').modal('show');

}
function LoadProfile() {
    $("#halias").html($("#userspan").html());
    GetServiceFunctions("GET", "ThreadsGeneration.svc/GetMyProfile").then(function (args) { LoadProfileCallBack(args) }, function (JQresponse, err) { alert(CallSerivceError(JQresponse, err)); });
}
function LoadProfileCallBack(args) {
    $("#txb_sofID").val(args);
    $("#txb_sofID").parent().parent().removeClass("error");
    $('#myModalProfile').modal('show');
}
function SetProfileCallBack(args) {
    $('#btncloseProfile').click();
}
function BindControlEvent() {
    $("#btnMP").click(function () {
        LoadProfile();
    });
    $("#SRModel").click(function ()
    {
        showSRRadio();
    });
    $("#btndoublesave").click(function () {
        $('#btnclosealert').click();
    });
    $("#btnSaveProfile").click(function () {
        if ($("#txb_sofID").val().trim() != "") {
            GetServiceFunctions("GET", "ThreadsGeneration.svc/SetMyProfile?sofID=" + $("#txb_sofID").val().trim()).then(function (args) { SetProfileCallBack(args) }, function (JQresponse, err) { alert(CallSerivceError(JQresponse, err)); });
        }
        else {
            $("#txb_sofID").parent().parent().addClass("error");
            $("#txb_sofID").attr("data-noty-options", "{\"text\":\"Please fill your stackoverflow id!\",\"layout\":\"top\",\"type\":\"error\",\"closeButton\":\"true\"}");
            var options = $.parseJSON($("#txb_sofID").attr('data-noty-options'));
            noty(options);
        }
    });
    $("#txb_sofID").focus(function () {
        $("#txb_sofID").parent().parent().removeClass("error");
    });
    $("#txbUT").focus(function () {
        $("#txbUT").parent().parent().removeClass("error");
    });
    $("#textareaUTComments").focus(function () {
        $("#textareaUTComments").parent().parent().removeClass("error");
    });
    $("#selectTS").change(function () {
        $("#hStatus").html(" in <u style=\"color:black;\">" + $("#selectTS").find("option:selected").text() + "</u> status ");
    });
    $("#selectSs").change(function () {
        //alert($("#selectTS").val())
        $("#hTgas").html("under <u style=\"color:black;\">" + $("#selectSs").find("option:selected").val() + "</u> tags");
    });
    $("#selectDelivery").change(function () {
        $("#hDelivery").html("which are <u style=\"color:black;\">" + $("#selectDelivery").find("option:selected").text() + "</u> Delivery");
    });
    $("#btnQuery").click(function () {
        var fromdate = $("#txbFromDate").val();
        var todate = $("#txbToDate").val();
        var onwer = $("#txbOwner").val();
        var tags = $("#selectSs").find("option:selected").val();
        var status = $("#selectTS").find("option:selected").text();
        var scenarioId = $("#selectSs").find("option:selected").attr("scenario");
        var delivery = $("#selectDelivery").find("option:selected").val()
        //alert(fromdate + todate + onwer + tags + scenarioId + status+delivery);
        if (!IsQueryConditionEmpty(fromdate, todate, onwer, scenarioId, status, delivery)) {
            LoadQuestionList(fromdate, todate, onwer, scenarioId, status, delivery)
        }
        else {
            var options = $.parseJSON($(this).attr('data-noty-options'));
            noty(options);
        }
    });
}

function IsQueryConditionEmpty(fromdate, todate, owner, scenarioId, status, delivery) {
    if (fromdate.trim() == "") {
        $("#btnQuery").attr("data-noty-options", '{"text":"Please fill date in [From]","layout":"top","type":"error","closeButton":"true"}');
        return true;
    }
    if (todate.trim() == "") {
        $("#btnQuery").attr("data-noty-options", '{"text":"Please fill date in [To]","layout":"top","type":"error","closeButton":"true"}');
        return true;
    }
    if (owner.trim() == "") {
        $("#btnQuery").attr("data-noty-options", '{"text":"Please fill data in [Owner], if you wanna select all threads, simply type all","layout":"top","type":"error","closeButton":"true"}');
        return true;
    }
    if (status.trim() == "") {
        $("#btnQuery").attr("data-noty-options", '{"text":"Please select thread status","layout":"top","type":"error","closeButton":"true"}');
        return true;
    }
    if (typeof (scenarioId) == "undefined") {
        $("#btnQuery").attr("data-noty-options", '{"text":"Please select scenario you wanna query", "layout":"top","type":"error","closeButton":"true"}');
        return true;
    }
    if (delivery.trim() == "") {
        $("#btnQuery").attr("data-noty-options", '{"text":"Please select delivery type","layout":"top","type":"error","closeButton":"true"}');
        return true;
    }
    return false;
}

function LoadQuestionList(fromdate, todate, owner, scenarioId, status, delivery) {
    EmptyList();
    GetServiceFunctions("GET", "ThreadsGeneration.svc/GetAllQuestion?fromdate=" + fromdate + "&todate=" + todate + "&owner=" + owner + "&scenarioId=" + scenarioId + "&status=" + status + "&delivery=" + delivery).then(function (args) { GenerateQuestionList(args) }, function (JQresponse, err) { alert(CallSerivceError(JQresponse, err)); });
}

function EmptyList() {
    $("#questionTBody").empty();
    var tr = $("<tr>");
    tr.append('<td  colspan=\"9\"> <img title="img/ajax-loaders/ajax-loader-7.gif" src="img/ajax-loaders/ajax-loader-6.gif"></td>');
    $("#questionTBody").append(tr);
}
function GenerateQuestionList(args) {
    $("#questionTBody").empty();
    $('.datatable').dataTable().fnClearTable();
    $.each(args, function (i, item) {
        var tr = $("<tr>");
        if (item.support_alias != "" && item.support_alias != undefined) {
            tr.append("<td class=\"right\"><span class=\"icon32 icon-color icon-locked seStatus\" style=\"cursor:pointer\" onclick=\"TakeOwner('" + item.question_id + "', '" + _userAlias + "', false, this)\"></span></td>");
        }
        else {
            tr.append("<td class=\"right\"><span class=\"icon32 icon-gray icon-unlocked seStatus\" style=\"cursor:pointer\" onclick=\"TakeOwner('" + item.question_id + "', '" + _userAlias + "', true, this)\"></span></td>");
        }
        tr.append("<td class=\"center tdalias\">" + item.support_alias + "</td>");
        tr.append("<td class=\"center tdstatus\"><span class=\"" + GetbgForStatus(item.status) + "\">" + item.status + "</span></td>");
        tr.append("<td style=\"width:3%\"><div class=\"btn-group\"><button class=\"btn dropdown-toggle\" data-toggle=\"dropdown\"><span class=\"caret\"></span></button><ul class=\"dropdown-menu\" style=\"list-style:none;\"><li><a style=\"\cursor:pointer\" onclick=\"SetThreadStatus('" + item.question_id + "', 'Waiting On Customer', this)\"><i class=\"icon-retweet\"></i> Waiting On Customer</a></li><li><a style=\"\cursor:pointer\" onclick=\"SetThreadStatus('" + item.question_id + "', 'Solution Deliver', this)\"><i class=\"icon-retweet\"></i> Solution Deliver</a></li><li><a style=\"\cursor:pointer\" onclick=\"SetThreadStatus('" + item.question_id + "', 'Escalated', this)\"><i class=\"icon-share\"></i> Escalated</a></li><li><a style=\"\cursor:pointer\" onclick=\"SetThreadStatus('" + item.question_id + "', 'Pending on Research', this)\"><i class=\"icon-search\"></i> Researching</a></li><li><a style=\"\cursor:pointer\" onclick=\"SetThreadStatus('" + item.question_id + "', 'Self-Answered', this)\"><i class=\"icon-ok\"></i> Self-Answered</a></li><li><a style=\"\cursor:pointer\" onclick=\"SetThreadStatus('" + item.question_id + "', 'Deleted In SO', this)\"><i class=\"icon-remove\"></i> Deleted In SO</a></li><li><a style=\"\cursor:pointer\" onclick=\"SetThreadStatus('" + item.question_id + "', 'OffTopic', this)\"><i class=\"icon-remove\"></i> OffTopic</a></li><li class=\"divider\"></li><li><a style=\"\cursor:pointer\" onclick=\" + DispatchOwner('" + item.question_id + "', this)\"><i class=\"icon-user\"></i> Dispatch Owner</a></li><li class=\"divider\"></li><li><a style=\"\cursor:pointer\" onclick=\" + GoToAnalysisTool('" + item.question_id + "', this)\"><i class=\"icon-list-alt\"></i> Jump to Analysis</a></li></ul></div></td>");
        tr.append('<td class=\"center\"><a data-rel="popover" data-content="' + item.body + '" title="' + item.title + '" href="' + item.link + '" target="_blank">' + item.title + '</a>' + formaticTags(item.tags) + '</td>');
        tr.append("<td class=\"center\">" + item.create_date + "</td>");
        tr.append("<td class=\"center\">" + item.active_date + "</td>");
        if (item.IRT != "N/A") {
            tr.append("<td class=\"center\">" + formatSeconds(item.IRT) + "</td>");
        }
        else {
            tr.append("<td class=\"center\">" + item.IRT + "</td>");
        }

        tr.append("<td class=\"center\"><span style=\"cursor:pointer\" class=\"btn btn-info btn-setting\" data-rel=\"tooltip\" title=\"Clieck Me To Add UT\" onclick=\"showModel('"+item.question_id+"', this)\" >"+item.utdata+"</span></td>");
        $("#questionTBody").append(tr);
    });
    //datatable
    reLoadTable();
    docReady();
    //Register table's control
}
function formaticTags(tags)
{
    var str = "<BR/>";
    tags[0].split(";").forEach(
   function (tag) {
       str += "  <span class='label' style='background-color:#E1ECF4;color:#39739d'>" + tag + "</span> ";

    });
    return str;
}
function DispatchOwner(question_id, obj)
{
    $("#selectSE").val("").trigger('liszt:updated');
    $("#selectSE").change();
    $('#myModalDispatchOwner').modal('show');
    $("#btnSaveSE").unbind("click");
    $("#btnSaveSE").click(function () {
        var seAlias = $("#selectSE").val();
        if (isErrorForSettingSE(seAlias, obj)) {
            TakeOwner(question_id, seAlias, true, $(obj).parent().parent().parent().parent().parent().find(".seStatus"));
            $("#btnCloseDispatchModel").click();
        }
    });
   
   
    //$(obj).attr("data-noty-options", "{\"text\":\"Daniel is working on this!\",\"layout\":\"top\",\"type\":\"success\",\"closeButton\":\"true\"}");
    //var options = $.parseJSON($(obj).attr('data-noty-options'));
    //noty(options);
}

function GoToAnalysisTool(question_id, obj)
{
    window.open("http://analyzeit.azurewebsites.net/Redirection/Navigate/"+question_id+"?external=sotool ", '_blank');
}
function isErrorForSettingSE(seAlias,obj)
{
    if (seAlias.trim() == "") {
        $(obj).attr("data-noty-options", "{\"text\":\"Please Select Engineer!\",\"layout\":\"top\",\"type\":\"error\",\"closeButton\":\"true\"}");
        var options = $.parseJSON($(obj).attr('data-noty-options'));
        noty(options);
        return false;
    }
    return true;
}
function TakeOwner(question_id, alias, isTake, obj) {
    var orgHTML = $(obj).parent().html();
    $(obj).parent().html("<img class=\"tempImg\" title=\"img/ajax-loaders/ajax-loader-1.gif\" src=\"img/ajax-loaders/ajax-loader-1.gif\">");
    GetServiceFunctions("GET", "ThreadsGeneration.svc/TakeThreadOwner?alias=" + alias + "&istake=" + isTake + "&question_id=" + question_id).then(function (args) { TakeOwnerCallBack(args, alias, question_id, orgHTML, obj, isTake) }, function (JQresponse, err) { alert(CallSerivceError(JQresponse, err)); });
}

function TakeOwnerCallBack(args, alias, question_id, orgHTML, obj, isTake) {
    if (args.takeownerresult) {
        if (isTake) {
            $(".tempImg").parent().parent().find(".tdalias").html(alias);
            $(".tempImg").parent().html("<span class=\"icon32 icon-color icon-locked seStatus\" style=\"cursor:pointer\" onclick=\"TakeOwner('" + question_id + "', '" + alias + "', false, this)\"></span>");
        }
        else {
            $(".tempImg").parent().parent().find(".tdalias").empty();
            $(".tempImg").parent().html("<span class=\"icon32 icon-gray icon-unlocked seStatus\" style=\"cursor:pointer\" onclick=\"TakeOwner('" + question_id + "', '" + alias + "', true, this)\"></span>");
        }
    }
    else {
        $(".tempImg").parent().attr("data-noty-options", "{\"text\":\"" + args.errormessage + "\",\"layout\":\"top\",\"type\":\"error\",\"closeButton\":\"true\"}");
        var options = $.parseJSON($(".tempImg").parent().attr('data-noty-options'));
        noty(options);
        $(".tempImg").parent().html(orgHTML);

    }
}

function SetThreadSelfAnswer(question_id, status, obj)
{
    
    
    
    $('#CCModel').modal('show');
    $("#btnSaveCC").unbind("click");
    $("#btnSaveCC").click(function () {

        var comment = $("#textareaConfirmComments").val();
        if (comment.trim() == "") {
            $("#textareaConfirmComments").parent().parent().addClass("error");
            $(obj).attr("data-noty-options", "{\"text\":\"Please fill Comments!\",\"layout\":\"top\",\"type\":\"error\",\"closeButton\":\"true\"}");
            var options = $.parseJSON($(obj).attr('data-noty-options'));
            noty(options);
            return false;
        } else
        {
            SetSelfAnswerComments(question_id, status, obj,comment);

        }
    });
}

function GetSelfAnswerComments(question_id, status, obj)
{
    $("#textareaConfirmComments").val("");
    GetServiceFunctions("GET", "ThreadsGeneration.svc/GetCustomerComment?question_id=" + question_id +"").then(function (args) {
        if (args == null) {
            $("#textareaConfirmComments").val("");
        } else {
            $("#textareaConfirmComments").val(args);
        }
        SetThreadSelfAnswer(question_id, status, obj);
    }, function (JQresponse, err) {
        alert(CallSerivceError(JQresponse, err));
    });
}

function SetSelfAnswerComments(question_id, status, obj,comment)
{
    GetServiceFunctions("GET", "ThreadsGeneration.svc/SetCustomerComment?question_id=" + question_id + "alias=" + _userAlias + "&status=1&cusomercomments=" + comment + "").then(function (args) {
        SetSelfAnswerCommentsCallBack(args, obj, status);
    }, function (JQresponse, err)
    {
        alert(CallSerivceError(JQresponse, err));
    });
    
}

function SetSelfAnswerCommentsCallBack(args, obj, status)
{
    $('#CCModel').modal('show');

    SetThreadStatusCallBack(args, obj, status)
}


function SetThreadStatus(question_id, status, obj) {
    $(obj).parent().parent().parent().parent().parent().find(".tdstatus").html("<img class=\"tempImg\" title=\"img/ajax-loaders/ajax-loader-1.gif\" src=\"img/ajax-loaders/ajax-loader-1.gif\">")
    GetServiceFunctions("GET", "ThreadsGeneration.svc/SetThreadStatus?status=" + status + "&question_id=" + question_id).then(function (args) { SetThreadStatusCallBack(args, obj, status) }, function (JQresponse, err) { alert(CallSerivceError(JQresponse, err)); });
    //alert(question_id + "&" + status);
}
function SetThreadStatusCallBack(args, obj, status) {
    $(obj).parent().parent().parent().parent().parent().find(".tdstatus").html("<span class=\"" + GetbgForStatus(status) + "\">" + status + "</span>");
}
function GetbgForStatus(status) {
    switch (status) {
        case "New Thread":
            return "label label-info";
            break;
        case "Waiting On Customer":
            return "label label-inverse";
            break;
        case "Answered":
            return "label label-success";
            break;
        case "Solution Deliver":
            return "label label-success";
            break;
        case "Re-Open/Follow":
            return "label label-important";
            break;
        case "Escalated":
            return "label";
            break;
        case "AnsweredByEscalation":
            return "label label-success";
            break;
        case "Pending on Research":
            return "label label-warning";
            break;
        case "Self-Answered":
            return "label label-success";
            break;
        case "Deleted In SO":   
            return "label";
            break;
        case "OffTopic":
            return "label";
            break;
    }
    return "label"
}

function notification() {
    var options = $.parseJSON($(this).attr('data-noty-options'));
    noty(options);
}